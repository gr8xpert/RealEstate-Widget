<?php
/**
 * Plugin Name: RealtySoft Connector
 * Plugin URI: https://realtysoft.ai
 * Description: Connects your WordPress site with RealtySoft property widget.
 *              Auto-injects the widget loader and enables SEO-friendly property detail URLs.
 * Version: 1.1.0
 * Author: RealtySoft
 * License: GPL v2 or later
 * Text Domain: realtysoft-connector
 */
if (!defined('ABSPATH')) exit;

class RealtySoft_Connector {
    private $default_slug = 'property';
    private $loader_url = 'https://realtysoft.ai/propertymanager/dist/realtysoft-loader.js';

    public function __construct() {
        // Rewrite rules
        add_action('init', [$this, 'add_rewrite_rules']);
        add_action('init', [$this, 'maybe_flush_rules'], 99);
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, 'flush_rewrite_rules');

        // Auto-inject widget scripts on frontend
        add_action('wp_head', [$this, 'inject_widget_scripts']);

        // Settings page
        add_action('admin_menu', [$this, 'add_settings_page']);
        add_action('admin_init', [$this, 'register_settings']);
    }

    // ─── Activation ──────────────────────────────────────────────

    public function activate() {
        $this->add_rewrite_rules();
        flush_rewrite_rules();
    }

    // ─── Rewrite Rules ───────────────────────────────────────────

    public function add_rewrite_rules() {
        $slugs = $this->get_slugs();
        foreach ($slugs as $entry) {
            $slug = sanitize_title($entry['slug'] ?? $this->default_slug);
            add_rewrite_rule(
                '^' . preg_quote($slug, '/') . '/(.+)/?$',
                'index.php?pagename=' . $slug,
                'top'
            );
        }
    }

    public function maybe_flush_rules() {
        $slugs = $this->get_slugs();
        $rules = get_option('rewrite_rules');
        if (!is_array($rules)) return;

        foreach ($slugs as $entry) {
            $slug = sanitize_title($entry['slug'] ?? $this->default_slug);
            $rule_key = '^' . preg_quote($slug, '/') . '/(.+)/?$';
            if (!isset($rules[$rule_key])) {
                flush_rewrite_rules(false);
                return;
            }
        }
    }

    // ─── Widget Script Injection ─────────────────────────────────

    /**
     * Inject RealtySoftConfig + loader script into <head> on frontend pages.
     * Only runs on the public site (not wp-admin).
     */
    public function inject_widget_scripts() {
        if (is_admin()) return;

        $config = get_option('realtysoft_widget_config', []);

        // Build the config object — only include non-empty values
        $js_config = [];

        if (!empty($config['ownerEmail'])) {
            $js_config['ownerEmail'] = $config['ownerEmail'];
        }
        if (!empty($config['inquiryThankYouMessage'])) {
            $js_config['inquiryThankYouMessage'] = $config['inquiryThankYouMessage'];
        }
        if (!empty($config['inquiryThankYouUrl'])) {
            $js_config['inquiryThankYouUrl'] = $config['inquiryThankYouUrl'];
        }
        if (!empty($config['siteName'])) {
            $js_config['siteName'] = $config['siteName'];
        }
        if (!empty($config['language'])) {
            $js_config['language'] = $config['language'];
        }

        // Property page slug from the slugs setting (first entry)
        $slugs = $this->get_slugs();
        if (!empty($slugs[0]['slug'])) {
            $js_config['propertyPageSlug'] = $slugs[0]['slug'];
        }

        // Output config script
        if (!empty($js_config)) {
            echo "<script>\nwindow.RealtySoftConfig = " . wp_json_encode($js_config, JSON_UNESCAPED_SLASHES) . ";\n</script>\n";
        }

        // Output loader script
        $loader = !empty($config['loaderUrl']) ? $config['loaderUrl'] : $this->loader_url;
        echo '<script src="' . esc_url($loader) . '"></script>' . "\n";
    }

    // ─── Helpers ─────────────────────────────────────────────────

    private function get_slugs() {
        return get_option('realtysoft_property_slugs',
            [['slug' => $this->default_slug, 'language' => 'Default']]);
    }

    // ─── Settings ────────────────────────────────────────────────

    public function add_settings_page() {
        add_options_page(
            'RealtySoft Settings',
            'RealtySoft',
            'manage_options',
            'realtysoft-settings',
            [$this, 'render_settings_page']
        );
    }

    public function register_settings() {
        register_setting('realtysoft_settings', 'realtysoft_property_slugs', [
            'type' => 'array',
            'default' => [['slug' => 'property', 'language' => 'Default']],
            'sanitize_callback' => [$this, 'sanitize_slugs']
        ]);

        register_setting('realtysoft_settings', 'realtysoft_widget_config', [
            'type' => 'array',
            'default' => [],
            'sanitize_callback' => [$this, 'sanitize_widget_config']
        ]);
    }

    public function sanitize_slugs($input) {
        if (!is_array($input)) {
            return [['slug' => $this->default_slug, 'language' => 'Default']];
        }
        $sanitized = [];
        foreach ($input as $entry) {
            if (empty($entry['slug'])) continue;
            $sanitized[] = [
                'slug' => sanitize_title($entry['slug']),
                'language' => sanitize_text_field($entry['language'] ?? 'Default')
            ];
        }
        return !empty($sanitized) ? $sanitized : [['slug' => $this->default_slug, 'language' => 'Default']];
    }

    public function sanitize_widget_config($input) {
        if (!is_array($input)) return [];
        return [
            'ownerEmail'              => sanitize_email($input['ownerEmail'] ?? ''),
            'inquiryThankYouMessage'  => sanitize_text_field($input['inquiryThankYouMessage'] ?? ''),
            'inquiryThankYouUrl'      => esc_url_raw($input['inquiryThankYouUrl'] ?? ''),
            'siteName'                => sanitize_text_field($input['siteName'] ?? ''),
            'language'                => sanitize_text_field($input['language'] ?? ''),
            'loaderUrl'               => esc_url_raw($input['loaderUrl'] ?? ''),
        ];
    }

    // ─── Settings Page ───────────────────────────────────────────

    public function render_settings_page() {
        $slugs  = $this->get_slugs();
        $config = get_option('realtysoft_widget_config', []);
        ?>
        <div class="wrap">
            <h1>RealtySoft Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('realtysoft_settings'); ?>

                <!-- ── Widget Configuration ── -->
                <h2>Widget Configuration</h2>
                <p>These settings are auto-injected into every page. No need to add scripts manually.</p>
                <table class="form-table">
                    <tr>
                        <th><label for="rs-owner-email">Owner Email</label></th>
                        <td>
                            <input type="email" id="rs-owner-email"
                                   name="realtysoft_widget_config[ownerEmail]"
                                   value="<?php echo esc_attr($config['ownerEmail'] ?? ''); ?>"
                                   class="regular-text"
                                   placeholder="agent@example.com" />
                            <p class="description">Inquiry form submissions are sent to this email.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="rs-thankyou-msg">Thank You Message</label></th>
                        <td>
                            <input type="text" id="rs-thankyou-msg"
                                   name="realtysoft_widget_config[inquiryThankYouMessage]"
                                   value="<?php echo esc_attr($config['inquiryThankYouMessage'] ?? ''); ?>"
                                   class="large-text"
                                   placeholder="Thank you for your inquiry! We will contact you within 24 hours." />
                            <p class="description">Shown after a user submits an inquiry form.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="rs-thankyou-url">Thank You Redirect URL</label></th>
                        <td>
                            <input type="url" id="rs-thankyou-url"
                                   name="realtysoft_widget_config[inquiryThankYouUrl]"
                                   value="<?php echo esc_attr($config['inquiryThankYouUrl'] ?? ''); ?>"
                                   class="regular-text"
                                   placeholder="https://example.com/thank-you" />
                            <p class="description">Optional. Redirect to this URL after inquiry submission instead of showing a message.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="rs-site-name">Site Name</label></th>
                        <td>
                            <input type="text" id="rs-site-name"
                                   name="realtysoft_widget_config[siteName]"
                                   value="<?php echo esc_attr($config['siteName'] ?? ''); ?>"
                                   class="regular-text"
                                   placeholder="<?php echo esc_attr(get_bloginfo('name')); ?>" />
                            <p class="description">Used in social sharing cards. Defaults to your site domain if empty.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="rs-language">Language</label></th>
                        <td>
                            <input type="text" id="rs-language"
                                   name="realtysoft_widget_config[language]"
                                   value="<?php echo esc_attr($config['language'] ?? ''); ?>"
                                   class="regular-text"
                                   placeholder="en_US" />
                            <p class="description">Widget language code (e.g. <code>en_US</code>, <code>es_ES</code>, <code>nl_NL</code>). Auto-detected if empty.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="rs-loader-url">Loader Script URL</label></th>
                        <td>
                            <input type="url" id="rs-loader-url"
                                   name="realtysoft_widget_config[loaderUrl]"
                                   value="<?php echo esc_attr($config['loaderUrl'] ?? ''); ?>"
                                   class="large-text"
                                   placeholder="<?php echo esc_attr($this->loader_url); ?>" />
                            <p class="description">Leave empty to use the default: <code><?php echo esc_html($this->loader_url); ?></code></p>
                        </td>
                    </tr>
                </table>

                <hr />

                <!-- ── Property Page Slugs ── -->
                <h2>Property Page Slugs</h2>
                <p>Each slug must match an existing WordPress page with the widget.
                   The first slug is also used as <code>propertyPageSlug</code> in the widget config.</p>
                <table class="widefat" id="rs-slugs-table">
                    <thead>
                        <tr>
                            <th>Language</th>
                            <th>Page Slug</th>
                            <th style="width: 50px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($slugs as $i => $entry): ?>
                        <tr>
                            <td>
                                <input type="text"
                                       name="realtysoft_property_slugs[<?php echo $i; ?>][language]"
                                       value="<?php echo esc_attr($entry['language']); ?>"
                                       placeholder="e.g. English"
                                       class="regular-text" />
                            </td>
                            <td>
                                <input type="text"
                                       name="realtysoft_property_slugs[<?php echo $i; ?>][slug]"
                                       value="<?php echo esc_attr($entry['slug']); ?>"
                                       placeholder="e.g. property"
                                       class="regular-text" />
                            </td>
                            <td>
                                <?php if ($i > 0): ?>
                                <button type="button" class="button rs-remove-slug">&times;</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <p>
                    <button type="button" class="button" id="rs-add-slug">+ Add Language</button>
                </p>

                <?php submit_button('Save Settings'); ?>
            </form>

            <hr />

            <h2>How It Works</h2>
            <ol>
                <li>The plugin auto-injects the widget loader script and config into every page <code>&lt;head&gt;</code></li>
                <li>Create a WordPress page for each language (e.g. <code>/property/</code>)</li>
                <li>Add the matching slug above</li>
                <li>The plugin adds a rewrite rule so URLs like <code>/property/villa-name-REF123</code>
                    serve the <code>/property/</code> page with HTTP 200 (instead of 404)</li>
                <li>The widget JS reads the URL and loads the correct property</li>
            </ol>

            <h2>Troubleshooting</h2>
            <p>If property detail URLs show 404 after saving:</p>
            <ol>
                <li>Go to <strong>Settings &rarr; Permalinks</strong></li>
                <li>Click <strong>Save Changes</strong> (this flushes rewrite rules)</li>
                <li>Try the property URL again</li>
            </ol>
        </div>

        <script>
        (function() {
            var table = document.getElementById('rs-slugs-table');
            var tbody = table.querySelector('tbody');
            var addBtn = document.getElementById('rs-add-slug');
            var rowCount = tbody.rows.length;

            addBtn.addEventListener('click', function() {
                var row = document.createElement('tr');
                row.innerHTML = '<td><input type="text" name="realtysoft_property_slugs[' + rowCount + '][language]" placeholder="e.g. Spanish" class="regular-text" /></td>' +
                    '<td><input type="text" name="realtysoft_property_slugs[' + rowCount + '][slug]" placeholder="e.g. propiedad" class="regular-text" /></td>' +
                    '<td><button type="button" class="button rs-remove-slug">&times;</button></td>';
                tbody.appendChild(row);
                rowCount++;
            });

            tbody.addEventListener('click', function(e) {
                if (e.target.classList.contains('rs-remove-slug')) {
                    e.target.closest('tr').remove();
                }
            });
        })();
        </script>
        <?php
    }
}

new RealtySoft_Connector();
